 app.controller('IndexController', ['$scope','MyFactory', function($scope, MyFactory){
$scope.onSubmit = function(){
	}
	$scope.welcomename = MyFactory.myHello('Gnanavel');
 }]);
