app.directive("validPasword",[function(){

return
{
	require : "ngModel";
	link : function(scope,element)

};

}]);