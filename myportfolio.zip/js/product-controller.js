 app.controller('ProductController',['$scope',function($scope){


 	$scope.products = [
 	{
 		"pid" : 1,
 		"ptitle" : "Sample",
 		"pdes" : "This is test",
 		"pimg" : "images/ve.jpg",
 		"pprice" : 2000,
 	},
 	{
 		"pid" : 2,
 		"ptitle" : "Sample1",
 		"pdes" : "This is test1",
 		"pimg" : "images/ve.jpg",
 		"pprice" : 33000,
 	},
 	{
 		"pid" : 3,
 		"ptitle" : "Sample2",
 		"pdes" : "This is test2",
 		"pimg" : "images/ve.jpg",
 		"pprice" : 20340,
 	},
 	{
 		"pid" : 4,
 		"ptitle" : "Sample3",
 		"pdes" : "This is test3",
 		"pimg" : "images/ve.jpg",
 		"pprice" : 26700,
 	},
 	];

 	$scope.cart = [];
 	$scope.addToCart = function(productIndex){
    $scope.cart.push($scope.products[productIndex]);
    $scope.products[productIndex].disable=true; 
  	};


 }]);













