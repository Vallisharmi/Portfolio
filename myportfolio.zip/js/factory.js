 app.factory('MyFactory', ['$rootScope', function($rootScope){
 	return{
 		myHello : function(name){
 			return "Hello " + name
 		}
 	}
 }])